import React from 'react'

import "./switchTabs.scss"

const SwitchTabs = () => {
  return (
    <div className='tabs'>SwitchTabs</div>
  )
}

export default SwitchTabs