// eslint-disable-next-line no-unused-vars
import React from 'react'

const SearchResult = () => {
  return (
    <div>SearchResult</div>
  )
}

export default SearchResult